package main

import (
	"os"

	"github.com/motemen/gore/cli"
)

func main() {
	os.Exit(cli.Run())
}
