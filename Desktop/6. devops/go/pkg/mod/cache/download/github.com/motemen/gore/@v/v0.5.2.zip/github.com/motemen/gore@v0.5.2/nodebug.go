// +build !debug

package gore

func debugf(format string, args ...interface{}) {
}
