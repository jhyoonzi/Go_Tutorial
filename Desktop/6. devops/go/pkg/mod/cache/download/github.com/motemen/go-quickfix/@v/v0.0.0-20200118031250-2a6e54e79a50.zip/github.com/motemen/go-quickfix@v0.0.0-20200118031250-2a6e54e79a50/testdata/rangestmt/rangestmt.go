package rangestmt

func F() {
	for _, _ := range []interface{}{} {
	}

	for i, x := range []interface{}{} {
	}
}
